window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("credit1").focus();
});

const gradePointsMap = {
  A: 4.0,
  B: 3.0,
  C: 2.0,
  D: 1.0,
  F: 0.0,
};

function calculateGPA() {
  let totalPoints = 0;
  let totalCredits = 0;
  let validEntries = 0;

  Array.from({ length: 5 }, (_, i) => i + 1).forEach((num) => {
    const creditInput = document.getElementById(`credit${num}`).value.trim();
    const gradeInput = document
      .getElementById(`grade${num}`)
      .value.trim()
      .toUpperCase();

    if (creditInput && gradeInput) {
      const credits = parseFloat(creditInput);
      const gradePoint = gradePointsMap[gradeInput];

      if (isNaN(credits)) {
        alert(`Credit hours for Course ${num} must be a number.`);
        return;
      }

      if (gradePoint === undefined) {
        alert(`Grade for Course ${num} must be A, B, C, D, or F.`);
        return;
      }

      totalPoints += gradePoint * credits;
      totalCredits += credits;
      validEntries++;
    }
  });

  if (validEntries < 2) {
    alert("Please enter at least 2 courses (Credit Hours and Grades).");
    return;
  }

  let gpa = totalPoints / totalCredits;
  document.getElementById("result").value = gpa.toFixed(2);
}

function resetGPA() {
  Array.from({ length: 5 }, (_, i) => i + 1).forEach((num) => {
    document.getElementById(`credit${num}`).value = "";
    document.getElementById(`grade${num}`).value = "";
  });
  document.getElementById("result").value = "";
  document.getElementById("credit1").focus();
}
